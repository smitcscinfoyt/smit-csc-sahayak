import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState } from "react";
import Home from "@/pages/Home";
import ChatWidget from "@/components/ChatWidget";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route>
        <div className="min-h-screen flex items-center justify-center">
          <div className="text-center">
            <h1 className="text-2xl font-bold gold-text">404</h1>
            <p className="mt-2 text-sm" style={{ color: "rgba(255,215,0,0.5)" }}>
              પૃષ્ઠ મળ્યું નહીં
            </p>
          </div>
        </div>
      </Route>
    </Switch>
  );
}

function App() {
  // Demo toggle — set to true for prime, false to show upgrade wall
  // In production: read from your auth session/localStorage
  const [isPrime] = useState<boolean>(() => {
    const param = new URLSearchParams(window.location.search).get("prime");
    if (param === "1" || param === "true") return true;
    if (param === "0" || param === "false") return false;
    return true; // default: prime in demo
  });

  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <Router />
        <ChatWidget isPrime={isPrime} />
      </WouterRouter>
    </QueryClientProvider>
  );
}

export default App;
