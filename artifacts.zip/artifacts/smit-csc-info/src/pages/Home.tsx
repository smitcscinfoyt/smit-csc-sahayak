export default function Home() {
  return (
    <div className="min-h-screen flex flex-col">
      {/* Navbar */}
      <nav
        className="sticky top-0 z-40 px-6 py-3 flex items-center justify-between"
        style={{
          background: "rgba(10,0,20,0.7)",
          backdropFilter: "blur(20px)",
          borderBottom: "1px solid rgba(255,215,0,0.15)",
        }}
      >
        <div className="flex items-center gap-3">
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, #ffd700, #ffaa00)",
              boxShadow: "0 0 16px rgba(255,215,0,0.4)",
            }}
          >
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
              <path d="M12 2C8 2 4 5 4 9c0 4 3 7 8 9 5-2 8-5 8-9 0-4-4-7-8-7z" fill="#2e004f"/>
              <circle cx="12" cy="9" r="3" fill="#ffd700"/>
            </svg>
          </div>
          <div>
            <div className="font-bold text-sm gold-text">Smit CSC Info</div>
            <div className="text-[10px]" style={{ color: "rgba(255,215,0,0.5)" }}>
              Digital India e-Services
            </div>
          </div>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span className="text-xs text-green-400">ઓનલાઈન</span>
        </div>
      </nav>

      {/* Hero */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-16 text-center gap-8">
        <div
          className="w-24 h-24 rounded-3xl flex items-center justify-center"
          style={{
            background: "linear-gradient(135deg, rgba(255,215,0,0.15), rgba(255,170,0,0.08))",
            border: "2px solid rgba(255,215,0,0.3)",
            boxShadow: "0 0 60px rgba(255,215,0,0.12), 0 20px 40px rgba(0,0,0,0.4)",
          }}
        >
          <svg width="48" height="48" viewBox="0 0 24 24" fill="none">
            <path
              d="M12 2C6.48 2 2 5.92 2 10.8c0 3.16 1.76 5.96 4.4 7.56L4 22l4.28-2.04C9.44 20.32 10.7 20.6 12 20.6c5.52 0 10-3.92 10-8.8S17.52 2 12 2z"
              fill="#ffd700"
              fillOpacity="0.85"
            />
            <circle cx="8.5" cy="10.5" r="1.3" fill="#2e004f"/>
            <circle cx="12" cy="10.5" r="1.3" fill="#2e004f"/>
            <circle cx="15.5" cy="10.5" r="1.3" fill="#2e004f"/>
          </svg>
        </div>

        <div className="max-w-lg">
          <h1 className="text-3xl sm:text-4xl font-bold mb-3 leading-tight">
            <span className="gold-text">Smit AI Sahayak</span>
          </h1>
          <p
            className="text-base sm:text-lg leading-relaxed"
            style={{ color: "rgba(255,215,0,0.65)" }}
          >
            ગ્રામ્ય ભારત માટે ડિજિટલ ઈ-સેવા.
            <br />
            CSC, સ્કીમ, અને સ૨કારી સેવા — બધું એક જ જગ્યાએ!
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 w-full max-w-xl mt-2">
          {[
            { icon: "🪪", name: "Aadhaar", sub: "નોંધણી / અપડેટ" },
            { icon: "📋", name: "PAN Card", sub: "નવું / કરેક્શન" },
            { icon: "🏗️", name: "e-Shram", sub: "કામદાર કાર્ડ" },
            { icon: "🌾", name: "PM Kisan", sub: "ખેડૂત સ્કીમ" },
            { icon: "🏥", name: "Ayushman", sub: "આ૨ોગ્ય સ્કીમ" },
            { icon: "🛂", name: "Passport", sub: "નવો / નવીકરણ" },
          ].map((s) => (
            <div
              key={s.name}
              className="flex flex-col items-center gap-2 p-4 rounded-2xl transition-all duration-200 hover:scale-[1.03] cursor-default"
              style={{
                background: "rgba(255,255,255,0.04)",
                border: "1px solid rgba(255,215,0,0.12)",
              }}
            >
              <span className="text-2xl">{s.icon}</span>
              <div>
                <div className="font-semibold text-xs gold-text">{s.name}</div>
                <div
                  className="text-[10px] mt-0.5"
                  style={{ color: "rgba(255,215,0,0.45)" }}
                >
                  {s.sub}
                </div>
              </div>
            </div>
          ))}
        </div>

        <p
          className="text-xs mt-2"
          style={{ color: "rgba(255,215,0,0.35)" }}
        >
          નીચે જમણી બાજુ ચેટ બબ્બલ ક્લિક કરી Smit AI Sahayak સાથે વાત કરો
        </p>
      </div>

      {/* Footer */}
      <footer
        className="text-center px-4 py-4 text-xs"
        style={{
          borderTop: "1px solid rgba(255,215,0,0.1)",
          color: "rgba(255,215,0,0.3)",
        }}
      >
        © 2025 Smit CSC Info · Digital India CSC Partner · AI Powered
      </footer>
    </div>
  );
}
