import { useState, useRef, useEffect, useCallback } from "react";

interface Message {
  role: "user" | "model";
  parts: Array<{ text: string }>;
}

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}
interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}
interface SpeechRecognitionInstance extends EventTarget {
  lang: string;
  continuous: boolean;
  interimResults: boolean;
  start(): void;
  stop(): void;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
}
declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionInstance;
    webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
  }
}

interface ChatWidgetProps {
  isPrime?: boolean;
}

const WELCOME_MESSAGE: Message = {
  role: "model",
  parts: [{ text: "નમસ્કાર! 🙏 હું **Smit AI Sahayak** છું.\n\nCSC સ્કીમ, document list, અને સ૨કારી યોજના — ગુજરાતીમાં પૂછો!" }],
};

const SERVICE_SHORTCUTS = [
  { icon: "🏗️", label: "e-Shram",   q: "e-Shram Card documents?" },
  { icon: "🌾", label: "PM Kisan",  q: "PM Kisan documents?" },
  { icon: "🏥", label: "Ayushman", q: "Ayushman Card documents?" },
  { icon: "🛂", label: "Passport",  q: "Passport documents?" },
];

function formatMessage(text: string) {
  return text.split("\n").map((line, i) => {
    line = line.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>");
    const isBullet = /^[\s•\-*]/.test(line.trim()) && line.trim().length > 1 &&
      (line.trim().startsWith("•") || line.trim().startsWith("-") || line.trim().startsWith("*"));
    if (isBullet) {
      return (
        <div key={i} className="flex gap-2 my-0.5">
          <span style={{ color: "#ffd700", flexShrink: 0, marginTop: 2 }}>•</span>
          <span dangerouslySetInnerHTML={{ __html: line.replace(/^[\s•\-*]+/, "") }} />
        </div>
      );
    }
    if (!line.trim()) return <div key={i} style={{ height: 6 }} />;
    return <div key={i} className="my-0.5" dangerouslySetInnerHTML={{ __html: line }} />;
  });
}

function UpgradeWall() {
  const plans = [
    { label: "માસિક",     price: "₹299",   period: "/માસ",       best: false },
    { label: "ત્રિ‍માસિક", price: "₹799",   period: "/3 મહિના",  best: true  },
    { label: "વાર્ષિક",   price: "₹2,499", period: "/વર્ષ",       best: false },
  ];
  return (
    <div style={{ display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center",
      height:"100%", gap:16, padding:"24px 16px", textAlign:"center" }}>
      <div style={{ width:56,height:56,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",
        background:"linear-gradient(135deg,rgba(255,215,0,.18),rgba(255,170,0,.08))",
        border:"2px solid rgba(255,215,0,.35)" }}>
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none">
          <path d="M3 17l3-8 5 5 5-8 3 8H3z" fill="#ffd700" fillOpacity=".9"/>
          <rect x="3" y="18" width="18" height="2" rx="1" fill="#ffd700"/>
        </svg>
      </div>
      <div>
        <p style={{ fontWeight:700, fontSize:14, color:"#ffd700", margin:"0 0 4px" }}>Prime Members Only</p>
        <p style={{ fontSize:12, lineHeight:1.6, color:"rgba(255,215,0,.6)", margin:0 }}>
          Advanced AI Sahayak ફક્ત<br/>Prime Members માટે ઉપલ‍બ્ધ છે
        </p>
      </div>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8, width:"100%" }}>
        {plans.map(p => (
          <div key={p.label} style={{ borderRadius:12, padding:"12px 8px", textAlign:"center",
            background: p.best ? "rgba(255,215,0,.12)" : "rgba(255,255,255,.04)",
            border: p.best ? "1.5px solid rgba(255,215,0,.45)" : "1px solid rgba(255,215,0,.12)" }}>
            {p.best && <div style={{ fontSize:8, fontWeight:700, color:"#ffd700", background:"rgba(255,215,0,.2)",
              borderRadius:20, padding:"1px 6px", display:"inline-block", marginBottom:2 }}>BEST</div>}
            <div style={{ fontSize:10, color:"rgba(255,215,0,.55)" }}>{p.label}</div>
            <div style={{ fontWeight:700, fontSize:15, color:"#ffd700" }}>{p.price}</div>
            <div style={{ fontSize:9, color:"rgba(255,215,0,.4)" }}>{p.period}</div>
          </div>
        ))}
      </div>
      <div style={{ width:"100%", borderRadius:12, padding:12, background:"rgba(255,215,0,.04)",
        border:"1px solid rgba(255,215,0,.1)", textAlign:"left" }}>
        {["📹 Step-by-step Video Tutorials","📄 Premium PDF Forms Download","💬 Personal WhatsApp Support","🤖 AI Sahayak — unlimited queries"]
          .map(b => <div key={b} style={{ fontSize:12, color:"rgba(255,215,0,.7)", marginBottom:4 }}>{b}</div>)}
      </div>
      <a href="https://chat.whatsapp.com/CS5vmo9R3yXKxlvBHP0EYh?mode=gi_t" target="_blank" rel="noopener noreferrer"
        style={{ width:"100%", padding:"12px 0", borderRadius:12, fontWeight:700, fontSize:14,
          background:"linear-gradient(135deg,#ffd700,#ffaa00)", color:"#2e004f",
          boxShadow:"0 4px 20px rgba(255,215,0,.25)", textDecoration:"none", display:"block", textAlign:"center" }}>
        🚀 Prime Upgrade કરો
      </a>
    </div>
  );
}

export default function ChatWidget({ isPrime = false }: ChatWidgetProps) {
  const [open, setOpen]         = useState(false);
  const [messages, setMessages] = useState<Message[]>(isPrime ? [WELCOME_MESSAGE] : []);
  const [input, setInput]       = useState("");
  const [loading, setLoading]   = useState(false);
  const [listening, setListening] = useState(false);
  const [notification, setNotification] = useState(true);

  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef  = useRef<HTMLInputElement>(null);
  const recogRef  = useRef<SpeechRecognitionInstance | null>(null);

  const baseUrl = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

  // When chat opens: clear notification + auto-focus
  useEffect(() => {
    if (open) {
      setNotification(false);
      setTimeout(() => inputRef.current?.focus(), 100);
    }
  }, [open]);

  // Lock body scroll while modal is open
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  const sendMessage = useCallback(async (text: string) => {
    if (!text.trim() || loading) return;
    const userMsg: Message = { role: "user", parts: [{ text: text.trim() }] };
    const newMessages = [...messages, userMsg];
    setMessages(newMessages);
    setInput("");
    setLoading(true);
    try {
      const history = newMessages.slice(1, -1); // skip pre-loaded welcome
      const res = await fetch(`${baseUrl}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text.trim(), history, isPrime }),
      });
      const data = (await res.json()) as { reply?: string };
      setMessages(prev => [...prev,
        { role: "model", parts: [{ text: data.reply ?? "ક્ષમા કરશો, ત્રુટિ આવી. ફરી પ્રયાસ કરો." }] }
      ]);
    } catch {
      setMessages(prev => [...prev,
        { role: "model", parts: [{ text: "ક્ષમા કરશો, સર્વર સાથે જોડાણ ન થઈ શક્યું." }] }
      ]);
    } finally {
      setLoading(false);
    }
  }, [messages, loading, baseUrl, isPrime]);

  const handleSend    = () => sendMessage(input);
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }
  };

  const toggleMic = () => {
    const SpeechRec = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (!SpeechRec) { alert("Voice Input browser support નથી."); return; }
    if (listening) { recogRef.current?.stop(); setListening(false); return; }
    const r = new SpeechRec();
    r.lang = "gu-IN"; r.continuous = false; r.interimResults = false;
    r.onresult = (e: SpeechRecognitionEvent) => { setInput(e.results[0][0].transcript); setListening(false); };
    r.onerror = () => setListening(false);
    r.onend   = () => setListening(false);
    r.start(); recogRef.current = r; setListening(true);
  };

  const clearChat = () => setMessages(isPrime ? [WELCOME_MESSAGE] : []);

  // ─── Shared inline styles ───────────────────────────────────────────────
  const BOT_AVATAR: React.CSSProperties = {
    width:28,height:28,borderRadius:"50%",flexShrink:0,marginRight:8,marginTop:2,
    background:"linear-gradient(135deg,#ffd700,#ffaa00)",
    boxShadow:"0 0 10px rgba(255,215,0,.25)",
    display:"flex",alignItems:"center",justifyContent:"center",
  };

  return (
    <>
      {/* ── Floating Bubble — hidden when modal is open ───────────────── */}
      {!open && (
        <button
          onClick={() => setOpen(true)}
          aria-label="Smit AI Sahayak ખોલો"
          className="widget-idle"
          style={{
            position:"fixed", bottom:24, right:24,
            width:64, height:64, borderRadius:"50%",
            display:"flex", alignItems:"center", justifyContent:"center",
            zIndex:99999,
            background:"linear-gradient(135deg,#2e004f,#5c009a)",
            border:"2px solid #ffd700",
            boxShadow:"0 0 24px rgba(255,215,0,.3),0 8px 32px rgba(46,0,79,.6)",
            cursor:"pointer", transition:"transform .2s",
          }}
        >
          <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
            <path d="M12 2C6.48 2 2 5.92 2 10.8c0 3.16 1.76 5.96 4.4 7.56L4 22l4.28-2.04C9.44 20.32 10.7 20.6 12 20.6c5.52 0 10-3.92 10-8.8S17.52 2 12 2z" fill="#ffd700"/>
            <circle cx="8.5" cy="10.5" r="1.2" fill="#2e004f"/>
            <circle cx="12"  cy="10.5" r="1.2" fill="#2e004f"/>
            <circle cx="15.5" cy="10.5" r="1.2" fill="#2e004f"/>
          </svg>
          {isPrime && (
            <span style={{ position:"absolute",top:-4,left:-4,width:20,height:20,borderRadius:"50%",
              background:"linear-gradient(135deg,#ffd700,#ffaa00)",color:"#2e004f",
              fontSize:9,fontWeight:700,display:"flex",alignItems:"center",justifyContent:"center" }}>★</span>
          )}
          {notification && (
            <span style={{ position:"absolute",top:-4,right:-4,width:16,height:16,borderRadius:"50%",
              background:"#ef4444",border:"2px solid #2e004f" }} className="animate-pulse"/>
          )}
        </button>
      )}

      {/* ── FULL-SCREEN CHAT MODAL (single div, covers everything) ──────── */}
      {open && (
        <div
          style={{
            position:"fixed", inset:0,           /* covers the ENTIRE viewport */
            zIndex:99998,                         /* above everything on page   */
            background:"rgb(8,0,18)",            /* fully opaque — nothing behind shows */
            display:"flex", flexDirection:"column",
            fontFamily:"'Noto Sans Gujarati',sans-serif",
          }}
        >
          {/* ── Header ─────────────────────────────────────────────────── */}
          <div style={{
            display:"flex",alignItems:"center",gap:12,padding:"12px 16px",flexShrink:0,
            background:"linear-gradient(135deg,rgb(38,0,65),rgb(60,0,105))",
            borderBottom:"1px solid rgba(255,215,0,.2)",
          }}>
            {/* Avatar */}
            <div style={{ width:40,height:40,borderRadius:"50%",flexShrink:0,
              background:"linear-gradient(135deg,#ffd700,#ffaa00)",
              boxShadow:"0 0 14px rgba(255,215,0,.35)",
              display:"flex",alignItems:"center",justifyContent:"center" }}>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                <path d="M12 2C6.48 2 2 5.92 2 10.8c0 3.16 1.76 5.96 4.4 7.56L4 22l4.28-2.04C9.44 20.32 10.7 20.6 12 20.6c5.52 0 10-3.92 10-8.8S17.52 2 12 2z" fill="#2e004f"/>
                <circle cx="8.5" cy="10.5" r="1.1" fill="#ffd700"/>
                <circle cx="12"  cy="10.5" r="1.1" fill="#ffd700"/>
                <circle cx="15.5" cy="10.5" r="1.1" fill="#ffd700"/>
              </svg>
            </div>
            {/* Title */}
            <div style={{ flex:1,minWidth:0 }}>
              <div style={{ fontWeight:700,fontSize:14,color:"#ffd700",display:"flex",alignItems:"center",gap:8,flexWrap:"wrap" }}>
                Smit AI Sahayak
                {isPrime && (
                  <span style={{ fontSize:9,padding:"2px 7px",borderRadius:20,fontWeight:700,
                    background:"rgba(255,215,0,.18)",color:"#ffd700",border:"1px solid rgba(255,215,0,.3)" }}>
                    PRIME ★
                  </span>
                )}
              </div>
              <div style={{ fontSize:11,color:"#4ade80",display:"flex",alignItems:"center",gap:6,marginTop:2 }}>
                <span style={{ width:6,height:6,borderRadius:"50%",background:"#4ade80",display:"inline-block" }}
                  className="animate-pulse"/>
                {isPrime ? "Prime Member · Online" : "Online"}
              </div>
            </div>
            {/* Clear */}
            {isPrime && (
              <button onClick={clearChat}
                style={{ fontSize:11,padding:"4px 10px",borderRadius:8,cursor:"pointer",
                  color:"#ffd700",border:"1px solid rgba(255,215,0,.25)",background:"transparent",
                  opacity:.7,marginRight:4 }}
                onMouseOver={e=>(e.currentTarget.style.opacity="1")}
                onMouseOut={e=>(e.currentTarget.style.opacity=".7")}>
                Clear
              </button>
            )}
            {/* Close */}
            <button onClick={() => setOpen(false)}
              style={{ width:32,height:32,borderRadius:"50%",border:"none",cursor:"pointer",
                background:"rgba(255,255,255,.08)",display:"flex",alignItems:"center",justifyContent:"center",
                opacity:.7 }}
              onMouseOver={e=>(e.currentTarget.style.opacity="1")}
              onMouseOut={e=>(e.currentTarget.style.opacity=".7")}>
              <svg width="13" height="13" fill="none" viewBox="0 0 24 24">
                <path d="M6 6l12 12M18 6L6 18" stroke="#ffd700" strokeWidth="2.5" strokeLinecap="round"/>
              </svg>
            </button>
          </div>

          {/* ── Service Shortcut Icons ──────────────────────────────────── */}
          <div style={{
            display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8,
            padding:"10px 16px",flexShrink:0,
            borderBottom:"1px solid rgba(255,215,0,.1)",
            background:"rgba(255,215,0,.025)",
          }}>
            {SERVICE_SHORTCUTS.map(s => (
              <button key={s.label} onClick={() => sendMessage(s.q)}
                style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:4,
                  padding:"8px 4px",borderRadius:12,cursor:"pointer",border:"1px solid rgba(255,215,0,.15)",
                  background:"rgba(255,255,255,.04)",transition:"all .2s",
                }}
                onMouseOver={e=>{e.currentTarget.style.background="rgba(255,215,0,.1)";e.currentTarget.style.borderColor="rgba(255,215,0,.4)";}}
                onMouseOut={e=>{e.currentTarget.style.background="rgba(255,255,255,.04)";e.currentTarget.style.borderColor="rgba(255,215,0,.15)";}}
              >
                <span style={{ fontSize:22 }}>{s.icon}</span>
                <span style={{ fontSize:10,fontWeight:600,color:"rgba(255,215,0,.75)" }}>{s.label}</span>
              </button>
            ))}
          </div>

          {/* ── Body ───────────────────────────────────────────────────── */}
          {!isPrime ? (
            <div style={{ flex:1,overflowY:"auto" }}><UpgradeWall /></div>
          ) : (
            <>
              {/* Messages */}
              <div style={{ flex:1,overflowY:"auto",padding:12,display:"flex",flexDirection:"column",gap:10,scrollbarWidth:"thin" }}>
                {messages.map((msg, i) => (
                  <div key={i} style={{ display:"flex",justifyContent:msg.role==="user"?"flex-end":"flex-start" }}
                    className="msg-animate">
                    {msg.role === "model" && (
                      <div style={BOT_AVATAR}>
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                          <path d="M12 2C6.48 2 2 5.92 2 10.8c0 3.16 1.76 5.96 4.4 7.56L4 22l4.28-2.04C9.44 20.32 10.7 20.6 12 20.6c5.52 0 10-3.92 10-8.8S17.52 2 12 2z" fill="#2e004f"/>
                        </svg>
                      </div>
                    )}
                    <div style={{
                      maxWidth:"78%",fontSize:13,lineHeight:1.65,borderRadius:16,padding:"10px 14px",
                      ...(msg.role==="user"
                        ? { background:"linear-gradient(135deg,#3d0070,#5c009a)",color:"#ffd700",borderBottomRightRadius:4,border:"1px solid rgba(255,215,0,.18)" }
                        : { background:"rgba(255,255,255,.06)",color:"rgba(255,215,0,.9)",borderBottomLeftRadius:4,border:"1px solid rgba(255,215,0,.1)" })
                    }}>
                      {msg.role==="model" ? formatMessage(msg.parts[0].text) : msg.parts[0].text}
                    </div>
                  </div>
                ))}

                {/* Typing indicator */}
                {loading && (
                  <div style={{ display:"flex",justifyContent:"flex-start" }} className="msg-animate">
                    <div style={BOT_AVATAR}>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none">
                        <path d="M12 2C6.48 2 2 5.92 2 10.8c0 3.16 1.76 5.96 4.4 7.56L4 22l4.28-2.04C9.44 20.32 10.7 20.6 12 20.6c5.52 0 10-3.92 10-8.8S17.52 2 12 2z" fill="#2e004f"/>
                      </svg>
                    </div>
                    <div style={{ padding:"12px 16px",borderRadius:16,borderBottomLeftRadius:4,
                      background:"rgba(255,255,255,.06)",border:"1px solid rgba(255,215,0,.1)" }}>
                      <div style={{ display:"flex",gap:6,alignItems:"center",height:16 }}>
                        <span className="typing-dot" style={{ width:8,height:8,borderRadius:"50%",background:"#facc15",display:"inline-block" }}/>
                        <span className="typing-dot" style={{ width:8,height:8,borderRadius:"50%",background:"#facc15",display:"inline-block" }}/>
                        <span className="typing-dot" style={{ width:8,height:8,borderRadius:"50%",background:"#facc15",display:"inline-block" }}/>
                      </div>
                    </div>
                  </div>
                )}
                <div ref={bottomRef}/>
              </div>

              {/* ── Input Bar ────────────────────────────────────────── */}
              <div style={{
                display:"flex",gap:8,alignItems:"center",padding:"10px 12px",flexShrink:0,
                borderTop:"1px solid rgba(255,215,0,.12)",background:"rgb(10,0,22)",
              }}>
                <input
                  ref={inputRef}
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="ગુજરાતીમાં લખો..."
                  disabled={loading}
                  style={{
                    flex:1,padding:"10px 16px",fontSize:13,borderRadius:12,outline:"none",
                    background:"rgba(255,255,255,.06)",border:"1.5px solid rgba(255,215,0,.2)",
                    color:"#ffd700",caretColor:"#ffd700",fontFamily:"inherit",
                  }}
                />
                {/* Mic */}
                <button onClick={toggleMic} disabled={loading}
                  title={listening ? "બંધ કરો" : "Voice Input"}
                  className={listening ? "mic-active" : ""}
                  style={{ width:40,height:40,borderRadius:12,border:"none",cursor:"pointer",flexShrink:0,
                    display:"flex",alignItems:"center",justifyContent:"center",
                    background:listening?"rgba(255,215,0,.22)":"rgba(255,255,255,.06)",
                    outline:`1.5px solid ${listening?"#ffd700":"rgba(255,215,0,.2)"}` }}>
                  {listening ? (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="#ffd700">
                      <rect x="8" y="5" width="8" height="2" rx="1"/>
                      <rect x="8" y="10" width="8" height="2" rx="1"/>
                      <rect x="8" y="15" width="8" height="2" rx="1"/>
                    </svg>
                  ) : (
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                      <rect x="9" y="2" width="6" height="12" rx="3" fill="#ffd700"/>
                      <path d="M5 10a7 7 0 0014 0" stroke="#ffd700" strokeWidth="2" strokeLinecap="round"/>
                      <line x1="12" y1="20" x2="12" y2="23" stroke="#ffd700" strokeWidth="2" strokeLinecap="round"/>
                      <line x1="8"  y1="23" x2="16" y2="23" stroke="#ffd700" strokeWidth="2" strokeLinecap="round"/>
                    </svg>
                  )}
                </button>
                {/* Send */}
                <button onClick={handleSend} disabled={loading || !input.trim()}
                  style={{ width:40,height:40,borderRadius:12,border:"none",cursor:"pointer",flexShrink:0,
                    display:"flex",alignItems:"center",justifyContent:"center",
                    background:"linear-gradient(135deg,#ffd700,#ffaa00)",
                    boxShadow:input.trim()?"0 4px 14px rgba(255,215,0,.28)":"none",
                    opacity:(!input.trim()||loading)?.4:1,transition:"opacity .2s" }}>
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                    <path d="M22 2L11 13" stroke="#2e004f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M22 2L15 22 11 13 2 9l20-7z" stroke="#2e004f" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
              </div>
            </>
          )}

          {/* Footer */}
          <div style={{ textAlign:"center",padding:"6px",fontSize:10,
            color:"rgba(255,215,0,.22)",borderTop:"1px solid rgba(255,215,0,.06)",flexShrink:0 }}>
            Smit CSC Info — Powered by Gemini AI
          </div>
        </div>
      )}
    </>
  );
}
