import { webSearchCache } from "./cache.js";

const TAVILY_URL = "https://api.tavily.com/search";

interface TavilyResult {
  title?: string;
  url?: string;
  content?: string;
  score?: number;
}

interface TavilyResponse {
  results?: TavilyResult[];
  answer?: string;
}

export async function searchGovWeb(query: string): Promise<string | null> {
  const cacheKey = `web:${query.trim().toLowerCase().slice(0, 80)}`;
  const cached = webSearchCache.get(cacheKey);
  if (cached) return cached;

  const apiKey = process.env.TAVILY_API_KEY;
  if (!apiKey) return null;

  try {
    const res = await fetch(TAVILY_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        api_key: apiKey,
        query,
        search_depth: "basic",
        include_domains: [
          "gov.in",
          "india.gov.in",
          "pmkisan.gov.in",
          "agmarknet.gov.in",
          "digitalindia.gov.in",
          "npci.org.in",
          "uidai.gov.in",
          "csc.gov.in",
        ],
        max_results: 4,
        include_answer: true,
      }),
      signal: AbortSignal.timeout(10000),
    });

    if (!res.ok) return null;
    const data = (await res.json()) as TavilyResponse;

    const parts: string[] = [];

    if (data.answer) {
      parts.push(`**AI Summary:** ${data.answer}`);
    }

    const results = (data.results ?? []).slice(0, 3);
    if (results.length) {
      parts.push("**સ્ત્રોત (Sources):**");
      for (const r of results) {
        if (r.title && r.url) {
          const snippet = r.content?.slice(0, 180) ?? "";
          parts.push(`• **${r.title}**\n  ${snippet}\n  🔗 ${r.url}`);
        }
      }
    }

    if (!parts.length) return null;

    const result = parts.join("\n\n");
    webSearchCache.set(cacheKey, result);
    return result;
  } catch {
    return null;
  }
}
