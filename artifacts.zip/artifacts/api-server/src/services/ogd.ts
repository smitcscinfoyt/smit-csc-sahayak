import { mandiCache, ogdCache } from "./cache.js";

const OGD_BASE = "https://api.data.gov.in/resource";

const RESOURCE_IDS = {
  mandiPrices: "9ef84268-d588-465a-a308-a864a43d0070",
} as const;

interface MandiRecord {
  state?: string;
  district?: string;
  market?: string;
  commodity?: string;
  variety?: string;
  arrival_date?: string;
  min_price?: string | number;
  max_price?: string | number;
  modal_price?: string | number;
}

interface OGDResponse {
  total?: number;
  records?: MandiRecord[];
}

export async function fetchMandiPrices(crop?: string): Promise<string | null> {
  const cacheKey = `mandi:all:${crop ?? "all"}`;
  const cached = mandiCache.get(cacheKey);
  if (cached) return cached;

  const apiKey = process.env.DATAGOV_API_KEY;
  if (!apiKey) return null;

  const url = new URL(`${OGD_BASE}/${RESOURCE_IDS.mandiPrices}`);
  url.searchParams.set("api-key", apiKey);
  url.searchParams.set("format", "json");
  url.searchParams.set("limit", "15");
  if (crop) url.searchParams.set("filters[commodity]", crop);

  try {
    const res = await fetch(url.toString(), { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const data = (await res.json()) as OGDResponse;
    if (!data.records?.length) return null;

    // Prefer Gujarat records; if none, use all available
    const gujaratRecs = data.records.filter(
      (r) => r.state?.toLowerCase() === "gujarat",
    );
    const recs = gujaratRecs.length ? gujaratRecs : data.records.slice(0, 10);

    const stateLabel = gujaratRecs.length
      ? "ગુજરાત મંડી ભાવ"
      : "ભારત મંડી ભાવ (આજે ગુજરાત ડેટા ઉપલ‍બ્ધ નથી)";

    const lines = recs.map(
      (r) =>
        `• **${r.commodity ?? "?"}** (${r.variety ?? "-"}) — ${r.market ?? "?"}, ${r.district ?? "?"}, ${r.state ?? "?"} | Min: ₹${r.min_price} Max: ₹${r.max_price} Modal: ₹${r.modal_price} | તારીખ: ${r.arrival_date ?? "-"}`,
    );
    const result = `**${stateLabel} (AGMARKNET — data.gov.in):**\n${lines.join("\n")}`;
    mandiCache.set(cacheKey, result);
    return result;
  } catch {
    return null;
  }
}

export async function fetchSchemeStats(scheme: string): Promise<string | null> {
  const cacheKey = `scheme:${scheme}`;
  const cached = ogdCache.get(cacheKey);
  if (cached) return cached;

  // Generic OGD search for scheme info
  const apiKey = process.env.DATAGOV_API_KEY;
  if (!apiKey) return null;

  // PM Kisan beneficiary dataset
  const url = new URL(
    `${OGD_BASE}/eba4b7c3-abb1-49fa-8c6e-39b0c0aec6e5`,
  );
  url.searchParams.set("api-key", apiKey);
  url.searchParams.set("format", "json");
  url.searchParams.set("limit", "5");

  try {
    const res = await fetch(url.toString(), { signal: AbortSignal.timeout(8000) });
    if (!res.ok) return null;
    const data = (await res.json()) as OGDResponse;
    if (!data.records?.length) return null;
    const result = `**${scheme} Gujarat ડેટા (data.gov.in):**\n${JSON.stringify(data.records.slice(0, 3), null, 2)}`;
    ogdCache.set(cacheKey, result);
    return result;
  } catch {
    return null;
  }
}
