import { fetchMandiPrices, fetchSchemeStats } from "./ogd.js";
import { searchGovWeb } from "./webSearch.js";

export type DataIntent =
  | "mandi_prices"
  | "pm_kisan"
  | "weather"
  | "scheme_live"
  | "none";

interface EnrichedData {
  intent: DataIntent;
  liveData: string | null;
  source: string | null;
}

// Gujarati + English + Hindi keywords for each intent
const MANDI_KEYWORDS = [
  // Gujarati
  "ભાવ", "મંડી", "ભાડ", "ખેત ઉત્પ", "અનાજ",
  "ઘઉ", "ડુંગળ", "કપાસ", "જીરૂ", "ટામેટ", "ચણ", "ભીંડ", "બટાટ",
  "ડાંગ", "મકાઈ", "મગફળ", "સોય", "રાઈ",
  // English
  "mandi", "market rate", "mandibhav", "agmarknet",
  "commodity price", "crop price", "market price",
  "wheat price", "onion price", "cotton price", "jeera price",
  "tomato price", "potato price", "paddy price",
  // Hindi
  "मंडी", "भाव", "दाम",
];

const PM_KISAN_KEYWORDS = [
  "pm kisan", "pmkisan", "kisan status", "kisan samman",
  "kisan installment", "kisan nidhi", "kisan beneficiary",
  "kisansamman", "pm-kisan",
];

const WEATHER_KEYWORDS = [
  "weather", "rainfall", "monsoon", "rain", "hava man",
  "ચોમાસ", "વરસાદ", "હવામ", "temperature", "imd",
  "वर्षा", "बारिश",
];

const SCHEME_LIVE_KEYWORDS = [
  "latest", "new rule", "update", "2025", "2026",
  "notification", "circular", "status check",
  "apply online", "form link", "official link",
  "sarkari yojana", "sarkarni yojana",
  "નવો નિયમ", "નવ‍ી અપ‍ડ‍ેટ", "ઓનલ‍ાઈન અ‍ર‍જ‍ી",
  "नया नियम", "अपडेट",
];

function detectIntent(query: string): DataIntent {
  const q = query.toLowerCase();

  if (MANDI_KEYWORDS.some((k) => q.includes(k.toLowerCase()))) return "mandi_prices";
  if (PM_KISAN_KEYWORDS.some((k) => q.includes(k.toLowerCase()))) return "pm_kisan";
  if (WEATHER_KEYWORDS.some((k) => q.includes(k.toLowerCase()))) return "weather";
  if (SCHEME_LIVE_KEYWORDS.some((k) => q.includes(k.toLowerCase()))) return "scheme_live";

  return "none";
}

function extractCrop(query: string): string | undefined {
  const CROP_MAP: Record<string, string> = {
    "ઘઉ": "Wheat", "wheat": "Wheat",
    "ડુંગળ": "Onion", "onion": "Onion",
    "કપાસ": "Cotton", "cotton": "Cotton",
    "મગફળ": "Groundnut", "groundnut": "Groundnut", "peanut": "Groundnut",
    "જીરૂ": "Jeera", "jeera": "Jeera", "cumin": "Jeera",
    "ટામેટ": "Tomato", "tomato": "Tomato",
    "ચણ": "Gram", "gram": "Gram", "chickpea": "Gram",
    "ભીંડ": "Bhindi", "bhindi": "Bhindi", "okra": "Bhindi",
    "બટાટ": "Potato", "potato": "Potato",
    "ડાંગ": "Paddy", "rice": "Paddy", "paddy": "Paddy",
    "મકાઈ": "Maize", "maize": "Maize", "corn": "Maize",
    "સોય": "Soyabean", "soybean": "Soyabean",
    "રાઈ": "Mustard", "mustard": "Mustard",
    "ઘ‍ઉ": "Wheat", // alternate spelling
  };
  const q = query.toLowerCase();
  for (const [key, val] of Object.entries(CROP_MAP)) {
    if (q.includes(key.toLowerCase())) return val;
  }
  return undefined;
}

export async function enrichQuery(query: string): Promise<EnrichedData> {
  const intent = detectIntent(query);

  if (intent === "mandi_prices") {
    const crop = extractCrop(query);

    // Try OGD first, fall back to Tavily web search for latest mandi rates
    const [ogdData, webData] = await Promise.all([
      fetchMandiPrices(crop),
      searchGovWeb(
        `${crop ? crop + " " : ""}mandi market price today Gujarat India agmarknet.gov.in`,
      ),
    ]);

    const liveData = ogdData ?? webData;
    return {
      intent,
      liveData,
      source: ogdData
        ? "AGMARKNET — data.gov.in"
        : webData
          ? "agmarknet.gov.in — web search"
          : null,
    };
  }

  if (intent === "pm_kisan") {
    const [webData, schemeData] = await Promise.all([
      searchGovWeb(
        `PM Kisan Samman Nidhi status check step by step Gujarat 2026 site:pmkisan.gov.in OR site:gov.in`,
      ),
      fetchSchemeStats("PM Kisan"),
    ]);
    const combined = [webData, schemeData].filter(Boolean).join("\n\n");
    return {
      intent,
      liveData: combined || null,
      source: combined ? "pmkisan.gov.in — data.gov.in" : null,
    };
  }

  if (intent === "weather") {
    const webData = await searchGovWeb(
      `Gujarat weather rainfall forecast ${new Date().getFullYear()} site:imd.gov.in OR site:gov.in`,
    );
    return {
      intent,
      liveData: webData,
      source: webData ? "IMD — imd.gov.in" : null,
    };
  }

  if (intent === "scheme_live") {
    const webData = await searchGovWeb(
      `${query} Gujarat government scheme official 2026 site:gov.in OR site:india.gov.in`,
    );
    return {
      intent,
      liveData: webData,
      source: webData ? "india.gov.in — government portals" : null,
    };
  }

  return { intent: "none", liveData: null, source: null };
}
