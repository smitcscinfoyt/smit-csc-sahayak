import { Router } from "express";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { enrichQuery } from "../services/dataEnricher.js";

const router = Router();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const KNOWLEDGE_FILE = path.resolve(__dirname, "../../../../knowledge.txt");

interface KnowledgeSection {
  header: string;
  content: string;
}

let cachedSections: KnowledgeSection[] | null = null;
let cachedMtime = 0;

function loadSections(): KnowledgeSection[] {
  try {
    const stat = fs.statSync(KNOWLEDGE_FILE);
    const mtime = stat.mtimeMs;
    if (cachedSections && mtime === cachedMtime) return cachedSections;

    const raw = fs.readFileSync(KNOWLEDGE_FILE, "utf-8");
    const sections: KnowledgeSection[] = [];
    const lines = raw.split("\n");
    let header = "General";
    let buf: string[] = [];

    for (const line of lines) {
      if (line.startsWith("## ")) {
        if (buf.length) sections.push({ header, content: buf.join("\n") });
        header = line.replace(/^#+\s*/, "").trim();
        buf = [line];
      } else {
        buf.push(line);
      }
    }
    if (buf.length) sections.push({ header, content: buf.join("\n") });

    cachedSections = sections;
    cachedMtime = mtime;
    return sections;
  } catch {
    return [];
  }
}

function retrieveContext(query: string): string {
  const sections = loadSections();
  if (!sections.length) return "";

  const q = query.toLowerCase();

  const ALWAYS_INCLUDE = [
    "Smit CSC Info",
    "Prime Membership",
    "Smart CSC Tools",
    "ફી માળખું",
    "સંપર્ક",
  ];

  const KEYWORD_MAP: Record<string, string[]> = {
    "જન્મ": ["જન્મ અને મરણ"],
    "birth": ["જન્મ અને મરણ"],
    "મરણ": ["જન્મ અને મરણ"],
    "death": ["જન્મ અને મરણ"],
    "ration": ["રેશન કાર્ડ"],
    "રેશન": ["રેશન કાર્ડ"],
    "aadhaar": ["આધાર કાર્ડ"],
    "આધાર": ["આધાર કાર્ડ"],
    "passport": ["પાસપોર્ટ"],
    "પાસપોર્ટ": ["પાસપોર્ટ"],
    "driving": ["ડ્રાઇવિંગ"],
    "licence": ["ડ્રાઇવિંગ"],
    "ll": ["ડ્રાઇવિંગ"],
    "dl": ["ડ્રાઇવિંગ"],
    "લાયસન્સ": ["ડ્રાઇવિંગ"],
    "rc": ["RC Book"],
    "rc book": ["RC Book"],
    "hp removal": ["RC Book"],
    "loan": ["RC Book"],
    "noc": ["RC Book"],
    "itr": ["ITR"],
    "income tax": ["ITR"],
    "આયકર": ["ITR"],
    "tax": ["ITR"],
    "nirman": ["ઈ-નિર્માણ"],
    "e-nirman": ["ઈ-નિર્માણ"],
    "નિર્માણ": ["ઈ-નિર્માણ"],
    "construction": ["ઈ-નિર્માણ"],
    "eshram": ["કૃષિ"],
    "e-shram": ["કૃષિ"],
    "shram": ["કૃષિ"],
    "kisan": ["કૃષિ"],
    "pm kisan": ["કૃષિ"],
    "surya": ["કૃષિ"],
    "solar": ["કૃષિ"],
    "સૂર્ય": ["કૃષિ"],
    "jamin": ["જમીન"],
    "jameen": ["જમીન"],
    "જમીન": ["જમીન"],
    "land": ["જમીન"],
    "mutation": ["જમીન"],
    "7/12": ["જમીન"],
    "8-a": ["જમીન"],
    "ayushman": ["આરોગ્ય"],
    "આયુષ્માન": ["આરોગ્ય"],
    "pension": ["આરોગ્ય", "કન્યા"],
    "widow": ["આરોગ્ય"],
    "namo": ["કન્યા", "આરોગ્ય"],
    "lakshmi": ["કન્યા"],
    "saraswati": ["કન્યા"],
    "shree": ["આરોગ્ય"],
    "vahli": ["કન્યા"],
    "dikri": ["કન્યા"],
    "kunwarbai": ["કન્યા"],
    "mameru": ["કન્યા"],
    "મામેરું": ["કન્યા"],
    "income": ["આવક", "ITR"],
    "આવક": ["આવક", "ITR"],
    "caste": ["આવક"],
    "જાતિ": ["આવક"],
    "ews": ["આવક"],
    "ncl": ["આવક"],
    "pan": ["MSME"],
    "msme": ["MSME"],
    "udyam": ["MSME"],
    "gumasta": ["MSME"],
    "shop act": ["MSME"],
    "marriage": ["અન્ય"],
    "લગ્ન": ["અન્ય"],
    "gazette": ["અન્ય"],
    "ગેઝેટ": ["અન્ય"],
    "csc id": ["અન્ય"],
    "scholarship": ["અન્ય"],
    "pmay": ["અન્ય"],
    "awas": ["અન્ય"],
    "biometric": ["Biometric"],
    "mantra": ["Biometric"],
    "morpho": ["Biometric"],
    "fingerprint": ["Biometric"],
    "prime": ["Prime Membership"],
    "membership": ["Prime Membership"],
    "tools": ["Smart CSC Tools"],
    "photo sign": ["Smart CSC Tools"],
    "pdf": ["Smart CSC Tools"],
    "image": ["Smart CSC Tools"],
  };

  const targetHeaders = new Set<string>(ALWAYS_INCLUDE);
  for (const [kw, headers] of Object.entries(KEYWORD_MAP)) {
    if (q.includes(kw)) headers.forEach((h) => targetHeaders.add(h));
  }

  const matched = sections.filter((s) =>
    [...targetHeaders].some((t) =>
      s.header.toLowerCase().includes(t.toLowerCase()),
    ),
  );

  const seen = new Set<string>();
  const deduped = matched.filter((s) => {
    if (seen.has(s.header)) return false;
    seen.add(s.header);
    return true;
  });

  return deduped.length
    ? deduped.map((s) => s.content).join("\n\n")
    : sections.map((s) => s.content).join("\n\n");
}

const SYSTEM_INSTRUCTION = `તમારું નામ "Smit AI Sahayak" છે અને તમે "Smit CSC Info" વેબસાઇટ માટે AI સહાયક છો.

**ભાષા નિયમ (STRICT):** ALWAYS ગુજરાતીમાં જ જવાબ આપો — ભલે user ગમે તે ભાષામાં પૂછે.

**વ્યક્તિત્વ:** વ્યાવસાયિક, મદદગાર અને મૈત્રીપૂર્ણ. ગુજરાતી સંસ્કૃતિ અનુસાર.

**ડેટા ઉપયોગ — STRICT PRIORITY ORDER:**
1. **Live Data Section** (જ્યારે present હોય) — real-time government data; MOST ACCURATE
2. **Knowledge Base Section** — Smit CSC Info internal knowledge
3. NEVER mix or guess. NEVER use general AI knowledge.

**Live Data Rules:**
- Live data present હોય ત્યારે — ત્યાંથી જ exact figures, prices, links copy કરો
- Source citation MANDATORY: જવાબ ના અંતે "📡 સ્ત્રોત: [source name]" ઉમેરો
- Mandi prices: table format — commodity, market, min/max/modal price, date

**"Information Not Found" — MANDATORY:**
EXACTLY:
"ક્ષમા કરશો, આ અંગેની સચોટ માહિતી અત્યારે મારી પાસે ઉપલ‍બ્ધ નથી. સાચી અને પૂરી જાણકારી માટે કૃપા કરીને અમારી સપોર્ટ ટીમનો સંપર્ક કરો અથવા અમારા WhatsApp ગ્રુપમાં મેસેજ કરો: https://chat.whatsapp.com/CS5vmo9R3yXKxlvBHP0EYh?mode=gi_t"

**Official Links:**
- WhatsApp Group: https://chat.whatsapp.com/CS5vmo9R3yXKxlvBHP0EYh?mode=gi_t
- YouTube: https://www.youtube.com/@SmitCSCInfo

**ફોર્મેટિંગ:** bullet points + **bold** headings. Mandi data → table. સ્પષ્ટ, ટૂંકો.`;

const NOT_PRIME_REPLY = `આ Advanced AI સુવિધા ફક્ત **Prime Members** માટે જ ઉપલ‍બ્ધ છે.

**Prime Membership Plans:**
• 📅 **માસિક (Monthly):** ₹299/માસ
• 📆 **ત્રિમાસિક (Quarterly):** ₹799 (3 મહિના)
• 🏆 **વાર્ષિક (Annual):** ₹2,499/વર્ષ

**Prime ના ફાયદા:**
• સર્વ સ્કીમ, document checklist — AI દ્વારા ઝડપી જવાબ
• Step-by-step Video Tutorials
• Premium PDF Forms Download
• Personal WhatsApp Support
• નવી યોજનાઓની ત્વ‍રિત Notification

👉 **Prime Membership માટે:** https://chat.whatsapp.com/CS5vmo9R3yXKxlvBHP0EYh?mode=gi_t`;

const SAMBANOVA_URL = "https://api.sambanova.ai/v1/chat/completions";
const MODELS = ["DeepSeek-V3.2", "DeepSeek-V3.1", "Meta-Llama-3.3-70B-Instruct"];

interface SambaMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

router.post("/chat", async (req, res) => {
  const { message, history, isPrime } = req.body as {
    message: string;
    history?: Array<{ role: string; parts: Array<{ text: string }> }>;
    isPrime?: boolean;
  };

  if (!message || typeof message !== "string") {
    res.status(400).json({ error: "message is required" });
    return;
  }

  if (!isPrime) {
    res.json({ reply: NOT_PRIME_REPLY, isPrimeRequired: true });
    return;
  }

  const apiKey = process.env.SAMBANOVA_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "SAMBANOVA_API_KEY is not configured" });
    return;
  }

  // Run knowledge retrieval and live data enrichment in parallel
  const [knowledgeContext, enriched] = await Promise.all([
    Promise.resolve(retrieveContext(message)),
    enrichQuery(message),
  ]);

  // Build layered context: live data first (higher priority), then knowledge base
  const contextParts: string[] = [];
  if (enriched.liveData) {
    contextParts.push(
      `**=== LIVE DATA (Real-time — ${enriched.source ?? "Government API"}) ===**\n${enriched.liveData}\n**=== END LIVE DATA ===**`,
    );
  }
  if (knowledgeContext) {
    contextParts.push(
      `**=== KNOWLEDGE BASE (Smit CSC Info) ===**\n${knowledgeContext}\n**=== END KNOWLEDGE BASE ===**`,
    );
  }

  const systemContent =
    contextParts.length
      ? `${SYSTEM_INSTRUCTION}\n\n${contextParts.join("\n\n")}`
      : SYSTEM_INSTRUCTION;

  const safeHistory: SambaMessage[] = (history ?? [])
    .filter((h) => h.role === "user" || h.role === "model")
    .map((h) => ({
      role: h.role === "model" ? "assistant" : "user",
      content: h.parts.map((p) => p.text).join(""),
    }));

  const messages: SambaMessage[] = [
    { role: "system", content: systemContent },
    ...safeHistory,
    { role: "user", content: message },
  ];

  let lastErrStatus = 500;
  let lastErrText = "";

  for (const model of MODELS) {
    try {
      const response = await fetch(SAMBANOVA_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages,
          max_tokens: 1024,
          temperature: 0.0,
          stream: false,
        }),
      });

      if (!response.ok) {
        lastErrStatus = response.status;
        lastErrText = await response.text();
        req.log.warn({ model, status: lastErrStatus, body: lastErrText }, "SambaNova model error — trying next");
        if (response.status === 429) break;
        continue;
      }

      const data = (await response.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
      };

      const text = data.choices?.[0]?.message?.content ?? "";
      req.log.info({ model }, "SambaNova responded");
      res.json({
        reply: text,
        liveDataUsed: !!enriched.liveData,
        source: enriched.source,
        model,
      });
      return;
    } catch (err: unknown) {
      req.log.warn({ model, err }, "SambaNova fetch error — trying next");
    }
  }

  req.log.error({ lastErrStatus, lastErrText }, "All SambaNova models failed");
  if (lastErrStatus === 429) {
    res.status(429).json({
      error: "quota_exceeded",
      reply: "ક્ષમા કરશો, અત્યારે હું વધુ પડતા ટ્રાફ‍િકને કારણે વ્‍યસ્ત છું, કૃ‍પા કરીને થોડ‍ીવાર પછી પ્‍રયત્ન કરો.",
    });
  } else {
    res.status(503).json({
      error: "service_unavailable",
      reply: "ક્ષ‍મા કરશો, AI સર્‍વ‍ર અત્‍યારે અનુપલ‍બ્ધ છે. થોડ‍ીવાર પ‍છી ફ‍રી પ‍્‍રયત્ન કરો.",
    });
  }
});

export default router;
